---
description: Recordatorio de Mantenimiento y Documentación (Manuales y Sync)
---

Este workflow actúa como un agente de memoria para asegurar que la documentación técnica y operativa nunca quede desactualizada tras un cambio importante en el código.

### 1. Actualización de Manuales (Obligatorio):
Cada vez que se añada una funcionalidad, se cambie una regla de negocio o se modifique la base de datos:
- **Manual Técnico (`tech_manual.md`):** Actualizar la sección de "Estructura de Datos", "Reglas de Negocio" y el conteo de líneas en "Estadísticas del Proyecto".
- **Manual de Operación (`tech_manual.md` o secciones operativas):** Asegurar que las instrucciones para el usuario final (Staff) reflejen los cambios en la UI.

### 2. Sincronización de Schema (`backend_schema.gs`):
Si hubo cambios en el Backend:
- **Aviso de Actualización:** Informar al usuario que DEBE copiar el código al editor de Apps Script.
- **Validación:** Comprobar que la versión en `backend_schema.gs` coincida con `CONFIG.VERSION` y el aviso en el frontend.

### 3. Registro en Roadmap (`roadmap.md`):
- Marcar como completadas las tareas realizadas.
- Actualizar el número de versión en la última línea del roadmap.

4. **Optimización de Recursos:**
- Si el cambio realizado soluciona un error recurrente o implementa una lógica compleja, invocar el workflow `/optimizacion-recursos` para registrar la "huella digital" de la solución y evitar re-ejecuciones costosas.

// turbo
5. **Verificación Proactiva:**
   - ¿Actualizaste `tech_manual.md` con las nuevas estadísticas de líneas?
   - ¿El workflow `sincronizar-version.md` disparó el aviso de actualización manual?
   - ¿Se registró la solución en la memoria de `/optimizacion-recursos` si aplica?
