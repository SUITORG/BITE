---
description: Solución y optimización de recursos mediante memoria de tareas y errores.
---
# Workflow: Optimización de Recursos y Soluciones (Huella Digital)

Este workflow se activa para evitar la re-ejecución innecesaria de tareas y optimizar la resolución de errores recurrentes.

### 1. Recepción de Tarea Nueva
- **Huella Digital**: Genera una "huella digital" única (hash/identificador) basada en los parámetros y contexto de la tarea.
- **Consulta de Memoria**: ¿Ya resolví algo idéntico antes?
    - **SÍ**: Aplica la solución guardada instantáneamente. **FIN**.
    - **NO**: Continúa al paso 2.

### 2. Pre-ejecución (Memoria de Errores)
- **Búsqueda Preventiva**: Busca errores similares del pasado en la base de conocimientos técnica.
- **Aplicación de Parches**: Intenta aplicar las soluciones que funcionaron en esos casos históricos.
    - **SI FUNCIONA**: Registra el éxito y termina. **FIN**.
    - **SI FALLA**: Ejecuta la tarea normalmente.

### 3. Post-ejecución y Registro
- **Resultado FALLIDO**: Guarda el error con detalles:
    - ¿Qué pasó? (Stacktrace/Logs)
    - ¿Cuándo ocurrió? (Timestamp)
    - Reincidencia: ¿Cuántas veces ha ocurrido?
- **Resultado EXITOSO**: Guarda la solución completa (código/pasos) para re-uso futuro sin re-calcular.

### 4. Mantenimiento y Limpieza de Memoria
*Este paso debe ejecutarse periódicamente o al detectar saturación de logs.*
- **Antigüedad**: Borrar errores de >30 días con baja frecuencia.
- **Uso**: Eliminar soluciones que no han sido consultadas en el último ciclo.
- **Duplicados**: Combinar registros de errores idénticos en un solo caso de estudio.

### 5. Priorización Inteligente
- **Prioridad**: Resolver primero los errores más frecuentes.
- **Persistencia**: Mantener en memoria "caliente" las soluciones más usadas.
- **Métricas de Ahorro**: Registrar el tiempo estimado ahorrado por cada uso de solución cacheada.
