---
description: Asegura que el Backend y Frontend mantengan la misma versión, fecha y hora de actualización.
---

Este workflow garantiza la integridad de versiones entre Google Apps Script (Backend) y la Aplicación Web (Frontend). Debe ejecutarse **obligatoriamente** cada vez que se realice una modificación en el código del backend o frontend.

### Reglas Críticas:
1. **Actualización Proactiva:** Siempre que el código del backend (`backend_schema.gs`) sea modificado, se debe incrementar la versión menor (ej. de v3.1.3 a v3.1.4).
29. **Aviso de Actualización de Schema:** Informar EXPLÍCITAMENTE al usuario que debe copiar el código de `backend_schema.gs` al editor de Google Apps Script. No basta con guardar el archivo local.
10. **Actualización de Manuales:** Sincronizar cambios en `tech_manual.md` y `roadmap.md` (Ver `/recordatorio-mantenimiento`).
11. **Auditoría de Líneas:** El bloque de auditoría en el encabezado del backend debe ser la "fuente de verdad" del tamaño del proyecto.

### Pasos a seguir:

1. **Actualización del Backend (`backend_schema.gs`):**
   - Localiza el encabezado del archivo.
   - Actualiza el número de **Versión**.
   - Actualiza la **Fecha** y **Hora** actual.
   - Asegúrate de que `CONFIG.VERSION` coincida exactamente.

2. **Sincronización con `app.js`:**
   - Asegúrate de que la lógica de `checkBackendVersion()` esté alineada (usualmente verificando el inicio de la cadena de versión).

3. **Verificación Visual (`index.html`):**
   - El elemento `gs-version-text` mostrará la versión dinámica; no requiere cambios manuales si el backend está actualizado.

4. **Validación de Auditoría:**
   - Ejecuta un comando para contar las líneas reales de: `app.js`, `style.css`, `index.html` y `backend_schema.gs`.
   - Actualiza el bloque de "AUDITORÍA DE LÍNEAS" en el backend y las estadísticas en `tech_manual.md`.

// turbo
5. **Comando de Verificación:**
   - Revisa las primeras 15 líneas de `backend_schema.gs` para confirmar la sincronización.
